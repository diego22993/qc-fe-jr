// store/auth.store.ts
import { create } from "zustand";
import type { Empleado } from "../features/empleados/types/empleado.types";

const TOKEN_KEY = "auth_token";

interface AuthState {
  empleado: Omit<Empleado, "contrasenia"> | null;
  token: string | null;
  isAuthenticated: boolean;
  setAuth: (empleado: Omit<Empleado, "contrasenia">, token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  empleado: null,
  token: localStorage.getItem(TOKEN_KEY),
  isAuthenticated: !!localStorage.getItem(TOKEN_KEY),

  setAuth: (empleado, token) => {
    localStorage.setItem(TOKEN_KEY, token);
    set({ empleado, token, isAuthenticated: true });
  },

  logout: () => {
    localStorage.removeItem(TOKEN_KEY);
    set({ empleado: null, token: null, isAuthenticated: false });
  },
}));
