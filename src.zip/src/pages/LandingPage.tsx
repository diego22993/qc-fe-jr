import React, { useEffect, useState } from "react";
import { DashboardLayout } from "../layouts/DashboardLayout";
import { WelcomeContent } from "../components/Landing";
import { landingApi } from "../api/landing.api";

export const LandingPage: React.FC = () => {
  const [username, setUsername] = useState<string>("Cargando...");

  useEffect(() => {
    landingApi.getCurrentUser().then((user) => {
      setUsername(user.username);
    });
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token"); // Limpia el token de sesión
    window.location.href = "/login"; // Redirección manual/fuerte al login
  };

  return (
    <DashboardLayout onLogout={handleLogout}>
      <WelcomeContent username={username} />
    </DashboardLayout>
  );
};
