// features/auth/hooks/useLogin.ts
import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { authService } from "../../../services/auth.service";
import { useAuthStore } from "../../../store/auth.store";

export const useLogin = () => {
  const navigate = useNavigate();
  const setAuth = useAuthStore((s) => s.setAuth);

  const { mutate, isPending, error } = useMutation({
    mutationFn: ({
      usuario,
      contrasenia,
    }: {
      usuario: string;
      contrasenia: string;
    }) => authService.login(usuario, contrasenia),

    onSuccess: (data) => {
      // data = { empleado, token }  ← según tu LoginResponseData
      setAuth(data.empleado, data.token);
      navigate("/", { replace: true }); // ← redirige a LandingPage
    },

    onError: (err: Error) => {
      console.error("[Login error]", err.message);
    },
  });

  return {
    login: mutate,
    isPending,
    errorMessage: error?.message ?? null,
  };
};
