// router/AppRouter.tsx
import { Routes, Route, Navigate } from "react-router-dom";
import { ProtectedRoute } from "./ProtectedRoute";
import { LoginPage } from "../pages/LoginPage";
import { EmpleadoDetallePage } from "../pages/EmpleadoDetallePage";
import { MainLayout } from "../layouts/MainLayout";
import { LandingPage } from "../pages/LandingPage";
import { EmpleadoPage } from "../pages/EmpleadoPage";

export const AppRouter = () => (
  <Routes>
    {/* Ruta pública */}
    <Route path="/login" element={<LoginPage />} />

    {/* Rutas protegidas */}
    <Route element={<ProtectedRoute />}>
      <Route element={<MainLayout />}>
        <Route index element={<LandingPage />} /> {/* / → Landing */}
        <Route path="/empleados" element={<EmpleadoPage />} />
        <Route path="/empleados/:id" element={<EmpleadoDetallePage />} />
      </Route>
    </Route>

    {/* Catch-all */}
    <Route path="*" element={<Navigate to="/login" replace />} />
  </Routes>
);
